/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author root
 */
@WebServlet(urlPatterns = {"/Update"})
public class Update extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            try (PrintWriter out = response.getWriter()){
                    
            out.println("<link rel='stylesheet' type='text/css' href='css/semantic.min.css'>");
            out.println("<link rel='stylesheet' type='text/css' href='https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css'>");
            out.println("<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js'></script>");
            out.println("<script src='https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.js'></script>");
            
            //loading class
            Class.forName("com.mysql.jdbc.Driver"); 
            
            //db connection
            Connection con=DriverManager.getConnection(  
            "jdbc:mysql://localhost:3306/qualzz","root","");  
            
            //satement with params
           // String sname = request.getParameter("sname");
            String sid; 
            sid = request.getParameter("sid");
            //out.println(sid);
            Statement stmt=con.createStatement(); 
            try{
                  sid = request.getParameter("sid");
                String sname = request.getParameter("sname");
                String interests = request.getParameter("interests");
                double percentage = Double.parseDouble(request.getParameter("percentage"));
                int rank = Integer.parseInt(request.getParameter("rank"));
                String date = request.getParameter("date");;
                
//                           out.println(sname);
//                            out.println(interests);
//                            out.println(percentage);
//                            out.println(rank);
//                            out.println(date);
            
                String sql1 = "update students set sname='"+sname+"' , interests='"+interests+"',percentage="+percentage+",rank="+rank+",dob='"+date+"' where sid='"+sid+"' ";
            
               // out.println("x");
               try{ 
                   int x = stmt.executeUpdate(sql1);
                   out.println("<div class='ui green message'>Updated  Succesfully"
                        + "&nbsp;&nbsp;&nbsp;<a href='../Qualzz/' class='ui blue button'><i class='home icon'></i>&nbsp;&nbsp; Home</a>"
                        + "</div>");
                 }catch(Exception e1){
                     out.println("<div class='ui red message'>Oops Error Occured"
                        + "&nbsp;&nbsp;&nbsp;<a href='../Qualzz/' class='ui blue button'><i class='home icon'></i>&nbsp;&nbsp; Home</a>"
                        + "</div>");
                 }
           
            
                
            }catch(Exception e){
                //out.println("empty string");
            }
            
            
           
            
            String sql = "select * from students where sid='"+sid+"'";
                //String sql;
            
            //String sql = "select * from students";
            ResultSet rs=stmt.executeQuery(sql);  
            
            //print out
            out.println("<div class='ui raised segment container'>");
            out.println("<div class='ui blue centered segment header'>Update Details of "+sid+"</div>");
            out.println("<div class='ui blue menu'>"
            +"<a class='ui blue  button item' href='/Qualzz'><i class='home icon'></i> Home</a>"
            +"<a class='ui blue button item' href='/Qualzz/Search' ><i class='search icon'></i> Students</a>"
            +"</div>");
            if(rs.next()){
             
                out.println(""
                   +"<div class='ui placeholder segment'>"
                    +" <div class='ui column very relaxed stackable grid'>"
                       +"<div class='column'> "
                         +"<form class='ui form' action='../Qualzz/Update' method='POST'>"
                           +"<div class='field'>"
                             +"<label>Student Name :</label>"
                             +"<div class='ui left icon input'>"
                               +"<input type='text' value='"+rs.getString(2)+"' placeholder='Enter Student Name' name='sname'>"
                               +"<i class='user icon'></i>"
                             +"</div>"
                           +"</div>"
                          +" <div class='field'>"
                             +"<label>Interests (Coding, ...)</label>"
                             +"<div class='ui left icon input'>"
                               +"<input type='text' value='"+rs.getString(3)+"' placeholder='Enter Interests' name='interests'>"
                                 
                               +"<i class='info  icon'></i>"
                             +"</div>"
                           +"</div>"

                           +"<div class='field'>"
                             +"<label>Percentage (85.2) </label>"
                             +"<div class='ui left icon input'>"
                               +"<input type='number' value="+rs.getInt(4)+" placeholder='Enter Percentage' name='percentage'>"
                               +"<i class='angle double up icon'></i>"
                             +"</div>"
                           +"</div>" 

                           +" <div class='field'>"
                             +"<label>Rank (1,2,..) </label>"
                             +"<div class='ui left icon input'>"
                             +"  <input type='number' value="+rs.getInt(5)+" placeholder='Enter rank' name='rank'>"
                               +"<i class='child icon'></i>"
                           +"  </div>"
                          +" </div> " 

                             +"<div class='field'>"
                             +"<label>Date of Birth </label>"
                             +"<div class='ui left icon input'>"
                               +"<input type='date' value='"+rs.getString(6)+"' placeholder='Enter DOB' name='date'>"
                               +"<i class='calendar alternate outline icon'></i>"
                                       
                             +"</div>"
                           +"</div> "
                           +"<input type='hidden' value='"+sid+"' name='sid'>"             
                           +"<div class='field'>"
                             +"<div class='ui right icon input'>"
                               +"<input type='submit'  value ='&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Update' class='ui blue submit button'>"
                              +" <i class='check white icon'></i>"
                            +" </div>"
                          +" </div>"
                           
                         +"</form>"
                     +"  </div>"
                   +"</div> ");
                       
                
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(Update.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Update.class.getName()).log(Level.SEVERE, null, ex);
        }
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
