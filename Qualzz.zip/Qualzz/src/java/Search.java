/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;  
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author root
 */
@WebServlet(urlPatterns = {"/Search"})
public class Search extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<link rel='stylesheet' type='text/css' href='css/semantic.min.css'>");
            out.println("<link rel='stylesheet' type='text/css' href='https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css'>");
            out.println("<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js'></script>");
            out.println("<script src='https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.js'></script>");
            
            //loading class
            Class.forName("com.mysql.jdbc.Driver"); 
            
            //db connection
            Connection con=DriverManager.getConnection(  
            "jdbc:mysql://localhost:3306/qualzz","root","");  
            
            //satement with params
            //String sname = request.getParameter("sname");
            String sid; 
            //String sid = request.getParameter("sid");
            //out.println(sid);
            Statement stmt=con.createStatement(); 
            //String sql = "select * from students where sid='"+sid+"'";
            
            String sql = "select * from students";
            ResultSet rs=stmt.executeQuery(sql);  
            
            //print out
            out.println("<div class='ui raised segment container'>");
            out.println("<div class='ui blue centered segment header'>Students Details</div>");
            out.println("<div class='ui blue menu'>"
            +"<a class='ui blue  button item' href='/Qualzz'><i class='home icon'></i> Home</a>"
            +"<a class='ui blue active  button item' href='/Qualzz/Search' ><i class='search icon'></i> Students</a>"
            +"</div>");
            out.println("<table class=\"ui single line table\">");
            out.println("<thead>"
                    + "<tr>"
                        + "<th>Student ID</th>"
                        + "<th>Student Name</th>"
                        + "<th>Interests</th>"
                        + "<th>Percentage</th>"
                        + "<th>Rank</th>"
                        + "<th>Action</th>"
                    + "</tr>"
                    + "</thead>");
            while(rs.next()){
                sid=rs.getString(1);
                out.println("<tr>"+"<td>"+rs.getString(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td>"+"<td>"+rs.getDouble(4)+"</td><td>"+rs.getInt(5)+"</td><td>"
                        + ""
                        + "<a class='ui green button' id='"+rs.getString(1)+"'>Show</a>"
                        + "<form style='display:inline;' action='/Qualzz/Update' method='POST' >"
                        + "<input type='hidden' value='"+rs.getString(1)+"' name='sid'>"
                        + "<input type='submit' value='Update' class='ui orange button'>"
                        + "</form>"
                        + "<form style='display:inline;' action='/Qualzz/Delete' method='POST' >"
                        + "<input type='hidden' value='"+rs.getString(1)+"' name='sid'>"
                        + "<input type='submit' value='Delete' class='ui red button'>"
                        + "</form>"     
                        + "</tr>");
                
                //modal here
                out.println("<div class='ui center aligned modal' id='"+rs.getString(1)+"show'>"
                        + "<i class='close red icon'></i>"
                        +"<div class='ui inverted blue raised segment centered header'>Student Data of "+sid+"</div>"
                        +"<br/>" 
                        +"<p class='ui' align=''><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Student Name</b> : "+rs.getString(2)+"</p>"
                        +"<p class='ui' align=''><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Interests </b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: "+rs.getString(3)+"</p>"
                        +"<p class='ui ' align=''><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Percentage </b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: "+rs.getDouble(4)+"</p>"
                        +"<p class='ui ' align=''><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Rank </b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: "+rs.getInt(5)+"</p>"        
                        +"<br/>"
                        + "</div>");
                
                //JS module to show popup
                
                out.println("<script>"
                        + "$('#"+sid+"').click(function(){"
                        + "$('#"+sid+"show').modal('show');})</script>");
                
                
                
            }
            out.println("</table>");
            out.println("</div>");
              
            con.close();  
        }catch (Exception ex) {
            Logger.getLogger(Search.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
         response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<link rel='stylesheet' type='text/css' href='css/semantic.min.css'>");
            out.println("<link rel='stylesheet' type='text/css' href='https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css'>");
            out.println("<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js'></script>");
            out.println("<script src='https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.js'></script>");
            
            //loading class
            Class.forName("com.mysql.jdbc.Driver"); 
            
            //db connection
            Connection con=DriverManager.getConnection(  
            "jdbc:mysql://localhost:3306/qualzz","root","");  
            
            //satement with params
            String sname = request.getParameter("sname");
            String sid; 
            sid = request.getParameter("sid");
            if(sid.equalsIgnoreCase("") && sname.equalsIgnoreCase("")){
                out.print("<script>"
                        + "window.location.href = '../Qualzz/Search"
                        + "</script>");
                        processRequest(request,response);
            }
            Statement stmt=con.createStatement(); 
            String sql = "select * from students where sid='"+sid+"' or sname='"+sname+"    ' ";
            
            //String sql = "select * from students";
            ResultSet rs=stmt.executeQuery(sql);  
            
            //print out
            out.println("<div class='ui raised segment container'>");
            out.println("<div class='ui blue centered segment header'>Students Details</div>");
            out.println("<table class=\"ui single line table\">");
            out.println("<thead>"
                    + "<tr>"
                        + "<th>Student ID</th>"
                        + "<th>Student Name</th>"
                        + "<th>Interests</th>"
                        + "<th>Percentage</th>"
                        + "<th>Rank</th>"
                        + "<th>Action</th>"
                    + "</tr>"
                    + "</thead>");
            while(rs.next()){
                sid=rs.getString(1);
                out.println("<tr>"+"<td>"+rs.getString(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td>"+"<td>"+rs.getDouble(4)+"</td><td>"+rs.getInt(5)+"</td><td>"
                        + ""
                        + "<a class='ui green button' id='"+rs.getString(1)+"'>Show</a>"
                        + "<form style='display:inline;' action='/Qualzz/Update' method='POST' >"
                        + "<input type='hidden' value='"+rs.getString(1)+"' name='sid'>"
                        + "<input type='submit' value='Update' class='ui orange button'>"
                        + "</form>"
                         
                        + "<form style='display:inline;' action='/Qualzz/Delete' method='POST' >"
                        + "<input type='hidden' value='"+rs.getString(1)+"' name='sid'>"
                        + "<input type='submit' value='Delete' class='ui red button'>"
                        + "</form>"
                        + "</td></tr>");
                
                //modal here
                out.println("<div class='ui center aligned modal' id='"+rs.getString(1)+"show'>"
                        + "<i class='close red icon'></i>"
                        +"<div class='ui inverted blue raised segment centered header'>Student Data of "+sid+"</div>"
                        +"<br/>" 
                        +"<p class='ui' align=''><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Student Name</b> : "+rs.getString(2)+"</p>"
                        +"<p class='ui' align=''><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Interests </b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: "+rs.getString(3)+"</p>"
                        +"<p class='ui ' align=''><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Percentage </b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: "+rs.getDouble(4)+"</p>"
                        +"<p class='ui ' align=''><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Rank </b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: "+rs.getInt(5)+"</p>"        
                        +"<br/>"
                        + "</div>");
                
                //JS module to show popup
                
                out.println("<script>"
                        + "$('#"+sid+"').click(function(){"
                        + "$('#"+sid+"show').modal('show');})</script>");
                
                
                
            }
            out.println("</table>");
            out.println("</div>");
              
            con.close();  
        }catch (Exception ex) {
            Logger.getLogger(Search.class.getName()).log(Level.SEVERE, null, ex);
        }
        //processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
